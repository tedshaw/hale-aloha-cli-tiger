package org.wattdepot.sensor.ted;
//package org.wattdepot.sensor.ted;
//
//import org.junit.Ignore;
//import org.junit.Test;
//
///**
// * Tests the TED 5000 sensor, at least as much as can be done without some simulation of the
// * sensor.
// * 
// * @author Robert Brewer
// */
//public class TestTed5000Sensor {
//
//  /**
//   * Tests the pollTed method. Except can't do that yet because of the structure of sensors.
//   */
//  @Test
//  @Ignore
//  public void testPollTed() {
//    
//  }
//}
